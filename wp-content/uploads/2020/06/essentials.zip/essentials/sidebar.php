<?php
/**
* The sidebar containing the main widget area
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package essentials
*/

global $post;
global $woocommerce;
$sidebar_id = 'sidebar-1';

$posttype = get_post_type( $post );

$order = '';
if ( $woocommerce && is_shop() || $woocommerce && is_product_category() || $woocommerce && is_product_tag() ) {
	if(!empty(pix_get_option('shop-layout'))&&pix_get_option('shop-layout')=='left-sidebar'){
		$order = 'order-sm-1';
	}
}
$sticky_class = 'sticky-bottom';
if( $posttype === 'page' ){
	if(pix_get_option('sidebar-page-sticky')){
		$sticky_class = pix_get_option('sidebar-page-sticky');
	}
	if(get_post_meta( get_the_ID(), 'pix-page-sidebar-sticky', true )){
		if(get_post_meta( get_the_ID(), 'pix-page-sidebar-sticky', true )!==''){
			$sticky_class = get_post_meta( get_the_ID(), 'pix-page-sidebar-sticky', true );
		}
	}
}

?>
<div class="sidebar col-12 col-md-4 <?php echo esc_html( $order ); ?>">
	<div class="w-100 h-100 d-flex align-items-start">
		<aside id="secondary" class="widget-area <?php echo esc_attr($sticky_class); ?> pix-sticky-sidebar pix-boxed-widgets w-100 pix-pb-30 pix-sidebar-adjust">
			<?php


			if ( function_exists( 'dynamic_sidebar' ) ) {
				if ( $woocommerce && is_shop() || $woocommerce && is_product_category() || $woocommerce && is_product_tag() || $woocommerce && is_product() ) {
					if(pix_get_option('sidebar-shop')){
						$sidebar_id = pix_get_option('sidebar-shop');
					}
					dynamic_sidebar( $sidebar_id );
				}
				elseif ( ( ( is_archive() ) || ( is_author() ) || ( is_category() ) || ( is_home() ) || ( is_single() ) || ( is_tag() ) )  ) {
					if( $posttype === 'post' ){

						if(pix_get_option('sidebar-blog')){
							$sidebar_id = pix_get_option('sidebar-blog');
						}
					}
					if( $posttype === 'page' ){
						if(pix_get_option('sidebar-page')){
							$sidebar_id = pix_get_option('sidebar-page');
						}
					}
					dynamic_sidebar( $sidebar_id );
				} elseif(is_page_template( array(
					'templates/template-blog-right-sidebar.php',
					'templates/template-blog-left-sidebar.php'
				)
			)){
				if(pix_get_option('sidebar-blog')){
					$sidebar_id = pix_get_option('sidebar-blog');
				}
				dynamic_sidebar( $sidebar_id );
			} elseif(is_page_template( array(
				'templates/template-right-sidebar.php',
				'templates/template-left-sidebar.php'
			)
			)){
				if(pix_get_option('sidebar-page')){
					$sidebar_id = pix_get_option('sidebar-page');
				}
				if(get_post_type()=='page' && get_post_meta( get_the_ID(), 'pix-page-sidebar', true )){
					$sidebar_id = get_post_meta( get_the_ID(), 'pix-page-sidebar', true );
				}
				dynamic_sidebar( $sidebar_id );
			} elseif ( $woocommerce && is_shop() || $woocommerce && is_product_category() || $woocommerce && is_product_tag() || $woocommerce && is_product() ) {
				if(pix_get_option('sidebar-shop')){
					$sidebar_id = pix_get_option('sidebar-shop');
				}
				dynamic_sidebar( $sidebar_id );
			} else {
				dynamic_sidebar( 'sidebar-1' );
			}
		}

		?>
	</aside>
</div>
</div>
