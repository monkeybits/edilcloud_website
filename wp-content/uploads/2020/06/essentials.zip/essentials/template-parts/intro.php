<?php
/**
 * Template part for displaying page intro
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package essentials
 */

$hide_top_area = false;
$post_type = get_post_type();
if(get_post_meta( get_the_ID(), 'pix-hide-top-area', true )){
    if(get_post_meta( get_the_ID(), 'pix-hide-top-area', true )==='1'){
        $hide_top_area = true;
    }
    if(get_post_type()=='page' ){
        if(empty(pix_get_option('pages-with-intro'))||!pix_get_option('pages-with-intro')){
            $hide_top_area = true;
        }
    }
}
if(!$hide_top_area){

    $divider_style = false;
    $divider_height = false;
    $is_class_color = false;
    $d_color = '#fff';

    $text_class = 'text-heading-default';
    $intro_dark = '';
    $intro_align = 'text-center';
    $intro_bred_align = 'justify-content-center';
    $intro_bg = 'bg-gray-2';
    $intro_opacity = 'pix-opacity-5';

    if ( function_exists( 'is_woocommerce_activated' ) ) {
        global $woocommerce;
    }

    $type_prefix = 'blog';
    $is_shop_post = false;
    if(get_post_type()=='portfolio' || is_page_template('templates/template-portfolio-full-width.php')
        || is_page_template('templates/template-portfolio-default.php') ){
        $type_prefix = 'portfolio';
    }elseif(get_post_type()=='post'
        || is_page_template('templates/template-blog-full-width.php')
        || is_page_template('templates/template-blog-with-offset.php')
        || is_page_template('templates/template-blog-without-sidebar.php')
        || is_page_template('templates/template-blog-left-sidebar.php')
        || is_page_template('templates/template-blog-right-sidebar.php')
    ){
        $type_prefix = 'blog';
    }elseif(
        get_post_type()=='product'
        || is_page_template('templates/template-shop.php')
    ){
        $type_prefix = 'shop';
        if ( class_exists( 'WooCommerce' ) ) {
            $is_shop_post = true;
        }
    }elseif(get_post_type()=='page' ){
        $type_prefix = 'pages';
    }




    if(!empty(pix_get_option($type_prefix.'-divider-style'))) $divider_style = pix_get_option($type_prefix.'-divider-style');
    if(!empty(pix_get_option($type_prefix.'-divider-height'))) $divider_height = pix_get_option($type_prefix.'-divider-height');
    if(!empty(pix_get_option($type_prefix.'-intro-light'))) $intro_dark = 'pix-dark';
    if(!empty(pix_get_option($type_prefix.'-intro-align'))){
        $intro_align = pix_get_option($type_prefix.'-intro-align');
        if($intro_align=='text-left') $intro_bred_align = 'justify-content-start';
        if($intro_align=='text-right') $intro_bred_align = 'justify-content-end';
    }
    if(!empty(pix_get_option($type_prefix.'-intr-bg-color'))){
        $intro_bg = 'bg-'. pix_get_option($type_prefix.'-intr-bg-color');
    }
    if(!empty(pix_get_option($type_prefix.'-intro-opacity'))){
        $intro_opacity = pix_get_option($type_prefix.'-intro-opacity');
    }
    if(!empty(pix_get_option($type_prefix.'-bg-color'))){
        if(pix_get_option($type_prefix.'-bg-color')=='custom'){
            $d_color = pix_get_option('custom-'.$type_prefix.'-bg-color');
            $is_class_color = false;
        }else{
            $d_color = 'bg-'.pix_get_option($type_prefix.'-bg-color');
            $is_class_color = true;
        }
     }



    $intro_default_padding = 150;

    // Default size for each divider
    $dividers_default_size = array(100, 250, 250, 150, 100, 200, 100,
                                   150, 250, 200, 150, 150, 140, 130,
                                   150, 130, 300, 300, 300, 300, 300,
                                   150, 250, 300);



        if(!$divider_height){
            $divider_height = $dividers_default_size[$divider_style];
        }
        $container_style = 'padding-top:150px;padding-bottom:150px;';
        // Padding amplification factor for each divider
        $dividers_padding_size = array(0.2, 0, 0, 0.4, 0.8, 0.2, 0.8,
                                       0.4, 0.1, 0.1, 0.4, 0.4, 0.8, 0.8,
                                       0.2, 0.2, 0.1, 0, 0, 0, 0,
                                       0.3, 0.3, 0.2);

        // Get extra padding depending on each divider
        $extra_padding = $divider_height * $dividers_padding_size[$divider_style];
        // Top divider padding
        $intro_padding_top = $divider_height * 0.5 + $extra_padding;
        // Bottom divider padding
        if(!$divider_style){
            $intro_padding_bottom = $divider_height * 0.35 + $extra_padding;
        }else{
            $intro_padding_bottom = $divider_height * 0.6 + $extra_padding;
        }

        // Padding CSS
        $container_style = 'padding-top:'.$intro_padding_top.'px;padding-bottom:'.$intro_padding_bottom.'px;';





    ?>


    <div class="pix-main-intro pix-intro-1 <?php echo esc_attr( $intro_bg ); ?>">
        <div class="pix-intro-img jarallax" data-jarallax data-speed="0.5" >
    		<?php
            $get_default = true;
            if(is_category()){
                $term_id = get_queried_object()->term_id;
                $customIntroImg = get_term_meta( $term_id, 'category_intro_img', true );
                if($customIntroImg){
                    echo wp_get_attachment_image( $customIntroImg, 'pix-xxl', false, array('class' => 'jarallax-img '.$intro_opacity) );
                    $get_default = false;
                }
            }
            if($get_default){
                if(!get_post_meta( get_the_ID(), 'pix-custom-intro-bg', true ) || get_post_meta( get_the_ID(), 'pix-custom-intro-bg', true )==''){
                    if(!empty(pix_get_option($type_prefix.'-intro-img'))){
                        echo wp_get_attachment_image( pix_get_option($type_prefix.'-intro-img')['id'], 'pix-xxl', false, array('class' => 'jarallax-img '.$intro_opacity) );
                    }
                }else{
                    echo wp_get_attachment_image( get_post_meta( get_the_ID(), 'pix-custom-intro-bg', true ), 'pix-xxl', false, array('class' => 'jarallax-img '.$intro_opacity) );
                }
            }

             ?>
    	</div>

        <div class="container <?php echo esc_attr( $intro_dark ); ?>" style="<?php echo esc_attr( $container_style ); ?>">
            <div class="pix-main-intro-placeholder"></div>

            <div class="row d-flex h-100 justify-content-center">


                <div class="col-xs-12 col-lg-12">
                    <div class="<?php echo esc_attr( $intro_align ); ?> my-2">
    					<?php
                        $is_shop = false;
                        if ( class_exists( 'WooCommerce' ) ) {
                            $is_shop = is_shop() || is_product_category();
                        }

                            if( (!is_front_page() && !is_404() && !is_search() && !is_archive() && !is_author()) || $is_shop ){
                                if($is_shop_post){
                                    ?>
                                    <h3 class="pix-sliding-headline font-weight-bold" data-class="<?php echo esc_attr( $text_class ); ?>"><?php echo esc_attr( woocommerce_page_title(false) ); ?></h3>
                                    <?php
                                }else{
                                    echo the_title( '<h3 class="pix-sliding-headline font-weight-bold" data-class="'.$text_class.'">', '</h3>', false );
                                }
                                ?>
                                <div>
                                <?php
                                    pix_get_breadcrumb('dark', $intro_bred_align);
                                ?>
                                </div>
                                <?php
                            }
    					?>
                    </div>
                </div>


            </div>
        </div>
        <div class="">
    	<?php
            if(!empty($divider_style)){
            	if( function_exists('pix_get_divider') ){
            		$b_divider_opts = array(
            			'd_divider_select'		=> $divider_style,
            			'd_layers'				=> '3',
            			'd_1_is_gradient'			=> '',
            			'd_1_color'					=> $d_color,
            			'is_class_color'					=> $is_class_color,
            			'd_2_is_gradient'			=> '',
            			'd_2_animation'				=> 'fade-in-up',
            			'd_2_delay'					=> '500',
            			'd_3_is_gradient'			=> '',
            			'd_3_color_2'				=> '',
            			'd_3_animation'				=> 'fade-in-up',
            			'd_3_delay'					=> '700',
            			'd_high_index'				=> '',
            			'd_flip_h'					=> '',
            			'extra_classes'					=> '',
            		);

                    if($divider_height){
                        echo pix_get_divider($divider_style, '#fff', 'bottom', false, '#fff', $b_divider_opts, $divider_height);
                    }else{
                        echo pix_get_divider($divider_style, '#fff', 'bottom', false, '#fff', $b_divider_opts);
                    }

            	}
        	}
    	?>
        </div>
    </div>



<?php

}
 ?>
