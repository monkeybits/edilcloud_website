=== Essentials ===

Author: PixFort
Tags: header-builder, footer-builder, divider-builder, popup-builder, premium-design, translation-ready
Theme URI: https://essentials.pixfort.com/

Requires at least: 4.5
License: Envato Marketplaces Split License
License URI: https://themeforest.net/licenses/standard
Text Domain: essentials

== Description ==

Essentials theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme.
4. Follow Essentials theme configuration and activation wizard.

== Changelog ==

= 1.0 - July 30 2020 =
* Initial release

== Copyright ==

Copyright pixfort.com All rights reserved 2020
