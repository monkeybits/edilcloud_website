if (typeof $ === "undefined") {
    if (jQuery != "undefined") {
        $ = jQuery;
    }
}
