<?php
/**
* Functions which enhance the header builder by hooking into WordPress
*
* @package essentials
*/

function pix_transient_menu( $args = array() ) {
    $defaults = array(
        'area'             => 'main',
        'depth'             => 3,
        'container_class' => 'collapse navbar-collapse ',
        'container_id' => 'navbarNav-',
        'menu_class' => 'navbar-nav nav-style-megamenu ',
        'fallback_cb' => '',
        'echo' => true,
        'menu' => '',
    );

    $args = wp_parse_args( $args, $defaults );

    $transient_name = 'pix_transient_menu-' . $args['area'] . '-' . $args['menu'] . '-' . $args['drop_bg'] . '-' . $args['dark_mode'];
    if ( false === get_transient( $transient_name ) ) {
        $menu_args = $args;
        $menu_args['echo'] = false;
        $cached_menu = wp_nav_menu( $menu_args );
        set_transient( $transient_name, $cached_menu, 0 );
        $pix_cached_menus = get_transient( 'pixfort_cached_menus' );
        if($pix_cached_menus){
            if (!in_array($transient_name, $pix_cached_menus)){
                array_push($pix_cached_menus, $transient_name);
                set_transient( 'pixfort_cached_menus', $pix_cached_menus, 0 );
            }
        }else{
            $menus = array($transient_name);
            set_transient( 'pixfort_cached_menus', $menus, 0 );
        }
        echo get_transient( $transient_name );
    }else{
        echo get_transient( $transient_name );
    }
}
add_action( 'wp_update_nav_menu', 'pix_update_menus' );
function pix_update_menus() {
    $menus = get_transient( 'pixfort_cached_menus' );
    if($menus){
        foreach( $menus as $menu ) {
            delete_transient( $menu );
        }
    }
}

function pix_get_header_elem($area, $data, $extra = false){
    $output = '';
    $opts = array();
    $opts['area']=$area;
    if(!empty($data->val)){
        foreach ($data->val as $i => $v) {
            if(!empty($v->val)){
                $opts[$v->name] = $v->val;
            }
        }
    }
    if(!empty($extra)){
        $opts = array_merge($opts, $extra);
    }

    switch ($data->name) {
        case 'text':
        $output = pix_get_header_text($opts);
        break;
        case 'link':
        $output = pix_get_header_link($opts);
        break;
        case 'phone':
        $output = pix_get_header_phone($opts);
        break;
        case 'address':
        $output = pix_get_header_address($opts);
        break;
        case 'space':
        $output = pix_get_header_space($opts);
        break;
        case 'divider':
        $output = pix_get_header_divider($opts);
        break;
        case 'social':
        $output = pix_get_header_social($opts);
        break;
        case 'search':
        $output = pix_get_header_search($opts);
        break;
        case 'logo':
        $output = pix_get_header_logo($opts);
        break;
        case 'menu':
        $output = pix_get_header_menu($opts);
        break;
        case 'cart':
        $output = pix_get_header_cart($opts);
        break;
        case 'wishlist':
        $output = pix_get_header_wishlist($opts);
        break;
        case 'language':
        $output = pix_get_header_language($opts);
        break;
        case 'btn':
        $output = pix_get_header_button($opts);
        break;
    }

    return $output;
}

function pix_get_header_text($opts){
    extract(shortcode_atts(array(
        'text' 		=> esc_attr__('Default Text', 'essentials'),
        'bold' 		=> '',
        'is_secondary_font' 		=> '',
        'color' 		=> 'body-default',
        'custom_color' 		=> '',
    ), $opts));
    $classes = '';
    $classes .= 'text-'.$color;

    if(!empty($bold)){
        $classes .= ' font-weight-bold';
    }
    if(!empty($is_secondary_font)){
        $classes .= ' secondary-font';
    }
    ?>
    <div class="d-inline-block text-sm pix-header-text pix-py-5 <?php echo esc_attr( $classes ); ?> mb-0"><?php echo do_shortcode($text); ?></div>
    <?php
}
function pix_get_header_link($opts){
    extract(shortcode_atts(array(
        'text' 		=> esc_attr__('Default Text', 'essentials'),
        'url' 		=> '',
        'target' 		=> '',
        'bold' 		=> '',
        'is_secondary_font' 		=> '',
        'arrow' 		=> '',
        'color' 		=> 'body-default',
        'custom_color' 		=> '',
    ), $opts));
    $classes = '';
    $classes .= 'text-'.$color;
    if(!empty($bold)){
        $classes .= ' font-weight-bold';
    }
    if(!empty($is_secondary_font)){
        $classes .= ' secondary-font';
    }
    $arrow_html = '';

    $custom = '';
    if(!empty($color)&&$color=='custom'){
        if(!empty($custom_color)){
            $custom = '"color:'.$custom_color.';';
        }
    }
    $target_out = '';
    if(!empty($target)&&$target){
        $target_out = 'target="_blank"';
    }
    ?>
    <div class="d-inline-block text-sm pix-py-5 pix-hover-item mb-0">
        <a class="<?php echo esc_attr($classes); ?> btn btn-link p-0 pix-header-text d-flex2 align-items-center2" href="<?php echo esc_url($url); ?>" <?php echo esc_attr( $target_out) . ' style="' . esc_attr( $custom ); ?>" >
            <span><?php echo esc_html($text); ?></span><?php if($arrow){ ?><i class="font-weight-bold pixicon-angle-right pix-hover-right ml-2"></i><?php } ?>
        </a></div>
        <?php
    }
    function pix_get_header_button($opts){
        extract(shortcode_atts(array(
            'text' 		=> esc_attr__('Default Text', 'essentials'),
            'url' 		=> '',
            'btn_popup_id' 		=> '',
            'area' 		=> '',
            'target' 		=> '',
            'bold' 		=> '',
            'is_secondary_font' 		=> '',
            'arrow' 		=> '',
            'color' 		=> 'body-default',
            'btn_style' 		=> '',
            'btn_color' 		=> 'light',
            'btn_text_color' 		=> '',
            'btn_rounded' 		=> '',
            'custom_btn_color' 		=> '#333',
            'custom_btn_text_color' 		=> '#fff',
        ), $opts));
        $classes = '';
        $custom = '';
        if($btn_style=='line'){
           $classes .= 'btn-line-'.$btn_color;
       }elseif ($btn_style=='outline') {
            $classes .= 'btn-outline-'.$btn_color;
        }elseif ($btn_style=='underline') {
            if (strpos($btn_color, 'dark-') === 0||strpos($btn_color, 'light-') === 0) {
                $classes .= ' btn-underline-primary ';
            }else{
             $classes .= 'btn-underline-'.$btn_color;
           }
         }elseif ($btn_style=='blink') {
              $classes .= 'btn-blink-'.$btn_color;

         }elseif ($btn_style=='link') {
              $classes .= 'btn-link text-'.$btn_color;
          }else{
            if (strpos($btn_color, 'dark-') === 0||strpos($btn_color, 'light-') === 0) {
                $classes .= ' bg-'.$btn_color;
                $classes .= ' btn-primary btn-custom-bg ';
            }else{
                $classes .= 'btn-'.$btn_color;
            }

        }
        if($btn_style=='flat'){
           $classes .= ' btn-flat';
       }
       if(!empty($btn_rounded)){
        $classes .= ' btn-rounded';
       }
       if(!empty($btn_text_color)){
        $classes .= ' text-'.$btn_text_color;
       }
       if($area!='header'){
           $classes .= ' btn-sm pix-py-10';
       }
       $popup_data = '';
       if(!empty($btn_popup_id)){
			$classes .= ' pix-popup-link';
			$nonce = wp_create_nonce("popup_nonce");
			$link = admin_url('admin-ajax.php?action=pix_popup_content&id='.$btn_popup_id.'&nonce='.$nonce);
			$popup_data = $link;
		}

        if($btn_color=='body-default'||$btn_color=='heading-default'||$btn_color=='gradient-primary'){
            $classes .= ' bg-'.$btn_color;
            if(!empty($custom_btn_text_color)){
                $custom .= 'color:#fff;';
            }
        }
        if(!empty($bold)){
            $classes .= ' font-weight-bold';
        }
        if(!empty($is_secondary_font)){
            $classes .= ' secondary-font';
        }
        if(!empty($btn_color)&&$btn_color=='custom'){
            if(!empty($custom_btn_color)){
                $custom .= 'background:'.$custom_btn_color.';';
            }

        }
        if(!empty($custom_btn_text_color)&&$btn_color=='custom'){
            $custom .= 'color:'.$custom_btn_text_color.';';
        }
        $target_out = '';
        if(!empty($target)&&$target){
            $target_out = 'target="_blank"';
        }
        ?>
        <div class="d-inline-flex align-items-center d-inline-block2 text-sm mb-0">
            <a class="btn <?php echo esc_attr( $classes ); ?> d-flex align-items-center mr-0" href="<?php echo esc_url( $url ); ?>" <?php echo esc_attr( $target_out) . ' style="' . esc_attr( $custom ); ?>" data-popup-link="<?php echo esc_attr($popup_data);?>" >
                <span><?php echo esc_html($text); ?></span>
            </a>
        </div>
        <?php
    }
    function pix_get_header_phone($opts){
        extract(shortcode_atts(array(
            'text' 		=> '',
            'bold' 		=> '',
            'is_secondary_font' 		=> '',
            'color'     => 'body-default',
            'custom_color' 	            	=> '',
        ), $opts));
        $classes = '';
        $classes .= 'text-'.$color;
        if(!empty($bold)){
            $classes .= ' font-weight-bold';
        }
        if(!empty($is_secondary_font)){
            $classes .= ' secondary-font';
        }
        $custom = '';
        if(!empty($color)&&$color=='custom'){
            if(!empty($custom_color)){
                $custom = 'color:'.$custom_color.';';
            }
        }
        $text = str_replace(' ', '', $text);
        ?>
        <a href="tel:<?php echo esc_attr($text);?>" class="text-sm d-inline-block2 pix-header-text d-inline-flex align-items-center pix-py-5 <?php echo esc_attr( $classes ); ?> mb-0" style="<?php echo esc_attr( $custom ); ?>" ><i class="pixicon-phone text-18 pix-mr-5 pix-header-icon-style"></i> <?php echo esc_html($text);?></a>
        <?php
    }
    function pix_get_header_address($opts){
        extract(shortcode_atts(array(
            'text' 		=> '',
            'bold' 		=> '',
            'is_secondary_font' 		=> '',
            'color'     => 'body-default',
            'custom_color' 	            	=> '',
        ), $opts));
        $classes = '';
        $classes .= 'text-'.$color;
        if(!empty($bold)){
            $classes .= ' font-weight-bold';
        }
        if(!empty($is_secondary_font)){
            $classes .= ' secondary-font';
        }
        $custom = '';
        if(!empty($color)&&$color=='custom'){
            if(!empty($custom_color)){
                $custom = 'color:'.$custom_color.';';
            }
        }
        if(empty($opts['text'])) $opts['text'] = '';
        ?>
        <div class="d-inline-block2 d-inline-flex align-items-center pix-header-text pix-py-5 text-sm <?php echo esc_attr( $classes ); ?> mb-0" style="<?php echo esc_attr( $custom ); ?>" ><i class="pixicon-map-pin-1-circle text-18 pix-mr-5 pix-header-icon-style"></i> <?php echo esc_html($text);?></div>
        <?php
    }
    function pix_get_header_space($opts){
        extract(shortcode_atts(array(
            'size' 		=> 'mx-2',
        ), $opts));
        ?>
        <span class="<?php echo esc_attr( $size ); ?>"></span>
        <?php
    }
    function pix_get_header_divider($opts){
        extract(shortcode_atts(array(
            'divider_size' 		=> 'mx-2',
            'divider_color' 		=> 'body-default',
            'divider_color_scroll' 		=> '',
            'divider_custom_color' 		=> '',
            'divider_height' 		=> '',
        ), $opts));
        $scroll = false;
        $main_class = '';
        if( $divider_color_scroll != ''){
            $main_class = 'is-main-divider';
            $scroll = true;
        }
        ?>
        <div class="d-inline-block pix-px-5 <?php echo esc_attr( $divider_size ); ?>">
            <div class="bg-<?php echo esc_attr( $divider_color ); ?> pix-header-divider <?php echo esc_attr( $main_class ); ?>  <?php echo esc_attr( $divider_height ); ?>" data-color="<?php echo esc_attr( $divider_color ); ?>" data-scroll-color="<?php echo esc_attr( $divider_color_scroll ); ?>"></div>
            <?php if($scroll){ ?>
                <div class="bg-<?php echo esc_attr( $divider_color_scroll ); ?> pix-header-divider is-scroll-divider <?php echo esc_attr( $divider_height ); ?>"></div>
            <?php } ?>
        </div>
        <?php
    }
    function pix_get_header_search($opts){
        extract(shortcode_atts(array(
            'size' 		=> 'mx-2',
            'color'     => 'dark-opacity-4',
            'custom_color' 	            	=> '',
        ), $opts));
        $custom = '';
        if(!empty($color)&&$color=='custom'){
            if(!empty($custom_color)){
                $custom = 'style="color:'.$custom_color.';"';
            }
        }
        ?>
        <a data-anim-type="fade-in-left" data-anim-delay="200" href="#" class="btn pix-header-btn btn-link p-0 pix-px-15 pix-search-btn pix-toggle-overlay m-0 scale2 animate-in d-inline-flex align-items-center text-<?php echo esc_attr( $color ); ?>" <?php echo esc_attr( $custom ); ?>><i class="pixicon-zoom text-18 pix-header-text font-weight-bold"></i></a>
        <?php
    }

    function pix_get_header_cart($opts){
        extract(shortcode_atts(array(
            'size' 		=> 'mx-2',
            'color'     => 'dark-opacity-4',
            'custom_color' 	            	=> '',
        ), $opts));
        $custom = '';
        if(!empty($color)&&$color=='custom'){
            if(!empty($custom_color)){
                $custom = 'style="color:'.$custom_color.';"';
            }
        }
        $i_count = 0;
        if ( function_exists( 'essentials_woocommerce_cart_count' ) ) {
            $i_count = essentials_woocommerce_cart_count();
        }
        ?>
        <a data-anim-type="fade-in-left" data-anim-delay="100" href="<?php echo esc_url( home_url( '/' ) ); ?>cart" class="btn pix-header-btn btn-link m-0 p-0 pix-header-text pix-px-15 fly-sm2 pix-cart-btn pix-open-sidebar text-<?php echo esc_attr( $color ); ?> d-inline-flex align-items-center animate-in"><i class="pixicon-bag-2 text-18 scale2 position-relative font-weight-bold" <?php echo esc_attr( $custom ); ?>></i><span class="cart-count badge-pill bg-primary"><?php echo esc_attr( $i_count ); ?></span></a>
        <?php
    }
    function pix_get_header_wishlist($opts){
        extract(shortcode_atts(array(
            'size' 		           => 'mx-2',
            'color'                => 'dark-opacity-4',
            'custom_color' 	       => ''
        ), $opts));
        $custom = '';
        if(!empty($color)&&$color=='custom'){
            if(!empty($custom_color)){
                $custom = 'style="color:'.$custom_color.';"';
            }
        }
        if ( function_exists( 'yith_wcwl_count_products' ) ) {
            if ( function_exists( 'yith_wcwl_is_wishlist_page' ) ) {
                $wishlist_page_id = yith_wcwl_object_id( get_option( 'yith_wcwl_wishlist_page_id' ) );
                if(!empty($wishlist_page_id)){
                    $i_count = yith_wcwl_count_products();
                    ?>
                    <a data-anim-type="fade-in-left" data-anim-delay="100" href="<?php echo get_page_link($wishlist_page_id); ?>" class="btn pix-header-btn btn-link m-0 p-0 pix-px-15 fly-sm2 pix-header-text pix-cart-btn text-<?php echo esc_attr( $color ); ?> animate-in"><i class="pixicon-heart text-18 position-relative font-weight-bold" <?php echo esc_attr( $custom ); ?>></i><span class="cart-count badge-pill bg-primary"><?php echo esc_attr( $i_count ); ?></span></a>
                    <?php
                }
            }
        }
    }
    function pix_get_header_language($opts){
        extract(shortcode_atts(array(
            'size' 		              => 'mx-2',
            'color' 		          => 'dark-opacity-4',
            'is_secondary_font' 	  => '',
            'custom_color' 		      => '',
            'area' 		              => ''
        ), $opts));
        $classes = '';
        $classes .= 'text-'.$color;
        if($area=='header'){
            $classes .= ' text-header-area';
        }
        if(!empty($is_secondary_font)){
            $classes .= ' secondary-font';
        }
        $custom = '';
        if($color=='custom'){
            if(!empty($custom_color)){
                $custom = 'color:'.$custom_color.';';
            }
        }

        if(defined('PIX_DEMO')){
            ?>
            <div class="dropdown pix-wpml-header-btn d-inline-block px-0" style="z-index:99999999999999;">
                <a href="#" class="pix-current-language pix-header-text text-sm font-weight-bold d-inline-block d-flex align-items-center <?php echo esc_attr( $classes ); ?>" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="<?php echo esc_attr( $custom ); ?>" >
                    <i class="pixicon-world-map-3 pix-mr-5 text-18"></i><span>English</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <div class="submenu-box shadow">
                        <a class="dropdown-item font-weight-bold text-sm" href="#">French</a>
                        <a class="dropdown-item font-weight-bold text-sm" href="#">German</a>
                    </div>
                </div>
            </div>
            <?php
        }else{
            if(function_exists('icl_get_languages')) {
                $languages = pix_get_languages();

                $current = '';
                $items = '';

                if(!empty($languages)){
                    ?>
                    <div class="dropdown pix-wpml-header-btn d-inline-block" style="z-index:99999999999;">
                        <?php
                        foreach($languages as $l){
                            if($l['active']){ ?>
                                <a href="#" class="pix-current-language font-weight-bold pix-header-text d-inline-block d-flex align-items-center <?php echo esc_attr( $classes ); ?>" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" <?php echo esc_attr( $custom ); ?>>
                                    <i class="pixicon-world-map-3 pix-mr-5"></i><span> <?php echo esc_attr( $l['native_name'] ); ?></span>
                                </a>
                                <?php
                                break;
                            }
                        }
                        ?>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <div class="submenu-box shadow">
                                <?php
                                foreach($languages as $l){
                                    if(!$l['active']){
                                        if(!empty($l['translated_name'])){
                                            ?>
                                            <a class="dropdown-item font-weight-bold text-sm" href="<?php echo esc_url( $l['url'] ); ?>"><?php echo esc_attr( $l['translated_name'] ); ?></a>
                                            <?php
                                        }else{
                                            ?>
                                            <a class="dropdown-item font-weight-bold text-sm" href="<?php echo esc_url( $l['url'] ); ?>"><?php echo esc_attr( $l['native_name'] ); ?></a>
                                            <?php
                                        }

                                    }
                                }

                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
        }
    }

    function pix_get_header_menu($opts){
        extract(shortcode_atts(array(
            'size' 		=> 'mx-2',
            'color'     => 'dark-opacity-4',
            'is_right_float' 	            	=> '',
            'custom_color' 	            	=> '',
            'menu' 	            	=> 'menu-1',
            'area' 	            	=> '',
            'drop_bg' 	            	=> 'white',
            'dark_mode' 	            	=> '',
            'nav_line_color' 	            	=> '',
            'active_line' 	            	=> '',
            'is_bold' 	            	=> '',
        ), $opts));
        if($area!='header'&&$area!='m_header'){
            ?>
            <nav class="navbar navbar-hover-drop navbar-expand-lg navbar-light p-0">
                <?php
            }
            if(defined('PIX_DEMO')){
                $nav_id = 'pixfort-'.$area.'-'.$menu.'-'.$drop_bg;
            }else{
                $nav_id = rand(10,1000);
            }

            ?>

            <button class="navbar-toggler hamburger--spin hamburger d-flex d-lg-none" type="button" data-toggle="collapse" data-target="#navbarNav-<?php echo esc_attr( $nav_id ); ?>" aria-controls="navbarNav-<?php echo esc_attr( $nav_id ); ?>" aria-expanded="false" aria-label="Toggle navigation">
                <span class="hamburger-box">

                    <span class="hamburger-inner bg-<?php echo esc_attr($color); ?>">
                        <span class="hamburger-inner-before bg-<?php echo esc_attr($color); ?>"></span>
                        <span class="hamburger-inner-after bg-<?php echo esc_attr($color); ?>"></span>
                    </span>

                </span>
            </button>
            <?php
            $menu_classes = $nav_line_color . ' ';
            $menu_classes .= $active_line . ' ';
            if(!empty($is_right_float)){
                $menu_classes .= 'justify-content-end ';
            }
            if(defined('PIX_DEMO') && false){

                pix_transient_menu(array(
                    // 'theme_location' => 'menu-1',
                    'area'             => $area,
                    'drop_bg'             => $drop_bg,
                    'dark_mode'             => $dark_mode,
                    'depth'             => 4,
                    'container_class' => 'collapse navbar-collapse align-self-stretch '.$menu_classes,
                    'container_id' => 'navbarNav-'.$nav_id,
                    'menu_class' => 'navbar-nav nav-style-megamenu align-self-stretch align-items-center',
                    'fallback_cb' => '',
                    'echo' => true,
                    'menu' => $menu,
                    'walker' => new wp_bootstrap_navwalker($opts)
                ));
            }else{
                wp_nav_menu(
                    array(
                        // 'theme_location' => 'menu-1',
                        'depth'             => 4,
                        'container_class' => 'collapse navbar-collapse align-self-stretch '.$menu_classes,
                        'container_id' => 'navbarNav-'.$nav_id,
                        'menu_class' => 'navbar-nav nav-style-megamenu align-self-stretch align-items-center ',
                        'fallback_cb' => '',
                        'echo' => true,
                        'menu' => $menu,
                        'walker' => new wp_bootstrap_navwalker($opts)
                    )
                );
            }

            if($area!='header'&&$area!='m_header'){
                ?>
            </nav>
            <?php
        }
    }

    function pix_get_header_logo($opts){
        extract(shortcode_atts(array(
            'height' 		=> '',
            'color' 		=> 'body-default',
            'custom_color' 		=> '',
            'area'             => '',
            'logo_img'             => '',
            'logo_scroll_img'             => '',
        ), $opts));
        $max = '';
        $classes = '';
        $themeDefault = false;
        if(!function_exists('essentials_core_plugin')){
            $classes .= 'text-heading-default';
            $themeDefault = true;
        }else{
            $classes .= 'text-'.$color;
        }

        $custom_logo_url = false;
        $mobileLogo = '';
        $scroll_logo_url = false;
        $logo_class = '';
        if(pix_get_option('scroll-logo-img')&&pix_get_option('scroll-logo-img')['url']){
            $scroll_logo_url = pix_get_option( 'scroll-logo-img' )['url'];
            $logo_class = 'pix-logo';
        }
        if(!empty($logo_scroll_img)&&$logo_scroll_img!=''){
            $scroll_logo_url = $logo_scroll_img;
            $logo_class = 'pix-logo';
        }
        if(pix_get_option('retina-logo-img')&&pix_get_option('retina-logo-img')['url']){
            $custom_logo_url = pix_get_option( 'retina-logo-img' )['url'];
        }elseif(pix_get_option('logo-img')&&pix_get_option('logo-img')['url']){
            $custom_logo_url = pix_get_option('logo-img')['url'];
        }
        if( !empty($area) && ($area == 'm_header' || $area == 'm_stack' || $area == 'm_topbar') && pix_get_option('mobile-logo-img')['url']  ){
            $custom_logo_url = pix_get_option( 'mobile-logo-img' )['url'];
        }
        if(!empty($logo_img)){
            $custom_logo_url = $logo_img;
        }

        if(empty($height)) $max = 'max-width:180px;';
        ?>
        <div class="slide-in-container">
            <div class="slide-in-container d-inline-block animate-in" data-anim-type="slide-in-up" style="<?php echo esc_attr( $max ); ?>">
                <?php
                $img_style = '';
                if(!empty($height)&&$height!=''){
                    $img_style = 'height:'.$height.';width:auto;';
                }


                if($themeDefault){
                    ?>
                    <h3 class="site-title"><strong><a class="navbar-brand pix-header-text font-weight-bold text-24 pix-mr-20 <?php echo esc_attr($classes); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></strong></h3>
                    <?php
                }else{
                    if( !empty($area) && ($area == 'm_header' || $area == 'm_stack' || $area == 'm_topbar') && pix_get_option('mobile-logo-img')['url']  ){
                        // $custom_logo_url = pix_get_option( 'mobile-logo-img' )['url'];
                        ?>
                        <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                            <img src="<?php echo esc_url( $custom_logo_url ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" style="<?php echo esc_attr( $img_style ); ?>">
                        </a>
                        <?php
                    }else{
                        // if(pix_get_option('scroll-logo-img')&&pix_get_option('scroll-logo-img')['url']){
                        //     $scroll_logo_url = pix_get_option( 'scroll-logo-img' )['url'];
                        //     if(!empty($logo_scroll_img)&&$logo_scroll_img!=''){
                        //         $scroll_logo_url = $logo_scroll_img;
                        //     }
                        //     $logo_class = 'pix-logo';
                        // }
                        if($custom_logo_url&&!empty($custom_logo_url)){

                            ?>
                            <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                                <img class="<?php echo esc_attr( $logo_class ); ?>" src="<?php echo esc_url( $custom_logo_url ); ?>" alt="<?php bloginfo( 'name' ); ?>" style="<?php echo esc_attr( $img_style ); ?>" >
                                <?php
                                if($scroll_logo_url){
                                    ?>
                                    <img class="pix-logo-scroll" src="<?php echo esc_url( $scroll_logo_url ); ?>" alt="<?php bloginfo( 'name' ); ?>" style="<?php echo esc_attr( $img_style ); ?>">
                                    <?php
                                }
                                 ?>
                            </a>
                            <?php
                        }else{
                            ?>
                            <h3 class="site-title"><strong><a class="navbar-brand pix-header-text font-weight-bold text-24 pix-mr-20 <?php echo esc_attr($classes); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></strong></h3>
                            <?php
                        }
                    }
                }

                ?>
            </div>
        </div>
        <?php
    }

    function pix_get_header_social($opts){
        extract(shortcode_atts(array(
            'bold' 		=> '',
            'color' 		=> 'body-default',
            'custom_color' 		=> '',
        ), $opts));
        $classes = '';
        $classes .= 'pix-header-text text-'.$color;
        $custom = '';
        $targetVal = '_self';
        if( pix_get_option('social-target-blank') ){
            $targetVal = '_blank';
        }
        if(!empty($color)&&$color=='custom'){
            if(!empty($custom_color)){
                $custom = 'style="color:'.$custom_color.';"';
            }
        }
        ?>
        <div class="pix-px-5 d-inline-block2 d-inline-flex align-items-between pix-social text-18">
            <?php
            if( pix_get_option('social-skype') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-skype') ); ?>" title="Skype"><i class="pixicon-skype px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-facebook') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-facebook') ); ?>" title="Facebook"><i class="pixicon-facebook3 px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-google') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-google') ); ?>" title="Google"><i class="pixicon-google px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-twitter') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-twitter') ); ?>" title="twitter"><i class="pixicon-twitter px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-vimeo') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-vimeo') ); ?>" title="vimeo"><i class="pixicon-vimeo px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-youtube') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-youtube') ); ?>" title="youtube"><i class="pixicon-youtube px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-flickr') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-flickr') ); ?>" title="flickr"><i class="pixicon-flickr px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-linkedin') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-linkedin') ); ?>" title="linkedin"><i class="pixicon-linkedin px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-pinterest') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-pinterest') ); ?>" title="pinterest"><i class="pixicon-pinterest px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-instagram') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-instagram') ); ?>" title="instagram"><i class="pixicon-instagram2 px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-dribbble') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-dribbble') ); ?>" title="dribbble"><i class="pixicon-dribbble px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-snapchat') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-snapchat') ); ?>" title="snapchat"><i class="pixicon-snapchat px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-telegram') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-telegram') ); ?>" title="telegram"><i class="pixicon-telegram px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-googleplay') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-googleplay') ); ?>" title="GooglePlay"><i class="pixicon-play2 px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-appstore') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-appstore') ); ?>" title="AppStore"><i class="pixicon-appstore px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-whatsapp') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-whatsapp') ); ?>" title="WhatsApp"><i class="pixicon-whatsapp2 px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-flipboard') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-flipboard') ); ?>" title="Flipboard"><i class="pixicon-flipboard px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-vk') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-vk') ); ?>" title="VK"><i class="pixicon-vk px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-discord') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-discord') ); ?>" title="Discord"><i class="pixicon-discord px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-tik-tok') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-tik-tok') ); ?>" title="tik-tok"><i class="pixicon-tik-tok px-2" ></i></a>
                <?php
            }
            if( pix_get_option('social-twitch') ){
                ?>
                <a class="d-flex align-items-center <?php echo esc_attr( $classes ); ?>" target="<?php echo esc_attr($targetVal); ?>" <?php echo esc_attr( $custom ); ?> href="<?php echo esc_url( pix_get_option('social-twitch') ); ?>" title="twitch"><i class="pixicon-twitch px-2" ></i></a>
                <?php
            }
            ?>
        </div>
        <?php
    }
